To run the program type in "bash makefile" on your command line and press enter.
I ran this in the flip server.