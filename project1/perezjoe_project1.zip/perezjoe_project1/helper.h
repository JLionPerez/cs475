#pragma once
float Ranf(float low, float high);
int Ranf(int ilow, int ihigh);
void TimeOfDaySeed();